# OOD-Project-Restaurent_management_system
This is an Obejct Oriented Desing project Which Contains -

1. Five Parent classes,
2. Each Parent classes has two child classes,
3. Each parent classes has minimum two variables and two methods,
4. Each child classes has minimum one variable and one method,
5. Encapsulation implemented,
6. One interface,
7. Two Overriden method,
8. Two Overloaded method,
9. Two abstract method,
10. Object Communications
