package RestaurantManagementSystem;

interface info {

    public void DisplayInfo();

    public void setMail(String mail);

    public String getMAil();
}
