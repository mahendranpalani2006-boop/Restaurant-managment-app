package com.app.yourrestaurantapp.models;

public class Help {

    private String id;
    private String title;
    private String content;

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
