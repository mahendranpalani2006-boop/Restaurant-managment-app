package com.app.yourrestaurantapp.models;

import java.io.Serializable;

public class Slider implements Serializable {

    public String slider_id;
    public String slider_title;
    public String slider_image;
    public String slider_description;

}
