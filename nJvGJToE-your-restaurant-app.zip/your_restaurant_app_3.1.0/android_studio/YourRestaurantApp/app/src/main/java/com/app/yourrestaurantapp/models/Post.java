package com.app.yourrestaurantapp.models;

import java.io.Serializable;

public class Post implements Serializable {

    public String post_id = "";
    public String post_title = "";
    public String post_image = "";
    public String post_description = "";
    public String post_date = "";

}
