package com.app.yourrestaurantapp.utilities;

public interface OnNotificationClickListener {

    void onComplete();

}