package com.app.yourrestaurantapp.models;

public class Category {

    private String category_id;
    private String category_name;
    private String category_image;
    private String product_count;

    public String getCategoryId() {
        return category_id;
    }

    public String getCategoryName() {
        return category_name;
    }

    public String getCategoryImage() {
        return category_image;
    }

    public String getProductCount() {
        return product_count;
    }

}
